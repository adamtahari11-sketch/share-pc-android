package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"
)

// ---------------------------------------------------------------- native helpers (Windows)

func runPS(script string, env ...string) (string, error) {
	if runtime.GOOS != "windows" {
		return "", errors.New("This action is available on Windows only.")
	}
	c := exec.Command("powershell", "-NoProfile", "-STA", "-NonInteractive", "-Command", script)
	c.Env = append(os.Environ(), env...)
	hide(c)
	out, err := c.Output()
	return strings.TrimSpace(string(out)), err
}

const psPrelude = `Add-Type -AssemblyName System.Windows.Forms; $o=New-Object System.Windows.Forms.Form; $o.TopMost=$true; $o.ShowInTaskbar=$false; $o.StartPosition='CenterScreen'; $o.Width=0; $o.Height=0; $o.Show(); `

func pickFolder(initial string) (string, error) {
	return runPS(psPrelude+`$d=New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description='Choose where received files are saved'; $d.SelectedPath=$env:CS_INIT; if($d.ShowDialog($o) -eq 'OK'){[Console]::Out.Write($d.SelectedPath)}`, "CS_INIT="+initial)
}

func pickFiles() ([]string, error) {
	out, err := runPS(psPrelude + `$d=New-Object System.Windows.Forms.OpenFileDialog; $d.Multiselect=$true; $d.Title='Choose files to send'; $d.Filter='All files (*.*)|*.*'; if($d.ShowDialog($o) -eq 'OK'){[Console]::Out.Write(($d.FileNames -join [Environment]::NewLine))}`)
	if err != nil || out == "" {
		return nil, err
	}
	var paths []string
	for _, l := range strings.Split(out, "\n") {
		if l = strings.TrimSpace(l); l != "" {
			paths = append(paths, l)
		}
	}
	return paths, nil
}

const runKey = `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`

func startupEnabled() bool {
	if runtime.GOOS != "windows" {
		return false
	}
	c := exec.Command("reg", "query", runKey, "/v", appName)
	hide(c)
	return c.Run() == nil
}

func setStartup(on bool) error {
	if runtime.GOOS != "windows" {
		return errors.New("Windows only")
	}
	var c *exec.Cmd
	if on {
		exe, err := os.Executable()
		if err != nil {
			return err
		}
		c = exec.Command("reg", "add", runKey, "/v", appName, "/t", "REG_SZ", "/d", `"`+exe+`" --background`, "/f")
	} else {
		c = exec.Command("reg", "delete", runKey, "/v", appName, "/f")
	}
	hide(c)
	if err := c.Run(); err != nil && on {
		return err
	}
	return nil
}

func openPath(p string) {
	var c *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		c = exec.Command("explorer", p)
	case "darwin":
		c = exec.Command("open", p)
	default:
		c = exec.Command("xdg-open", p)
	}
	hide(c)
	_ = c.Start()
}

func openPanel(port int) {
	u := fmt.Sprintf("http://127.0.0.1:%d/", port)
	if runtime.GOOS == "windows" {
		pf, pf86, la := os.Getenv("ProgramFiles"), os.Getenv("ProgramFiles(x86)"), os.Getenv("LocalAppData")
		cands := []string{
			filepath.Join(pf86, `Microsoft\Edge\Application\msedge.exe`),
			filepath.Join(pf, `Microsoft\Edge\Application\msedge.exe`),
			filepath.Join(pf, `Google\Chrome\Application\chrome.exe`),
			filepath.Join(pf86, `Google\Chrome\Application\chrome.exe`),
			filepath.Join(la, `Google\Chrome\Application\chrome.exe`),
			filepath.Join(pf, `BraveSoftware\Brave-Browser\Application\brave.exe`),
		}
		for _, b := range cands {
			if _, err := os.Stat(b); err == nil {
				c := exec.Command(b, "--app="+u, "--window-size=520,900",
					"--user-data-dir="+filepath.Join(configDir(), "window"),
					"--no-first-run", "--no-default-browser-check")
				if c.Start() == nil {
					return
				}
			}
		}
		c := exec.Command("rundll32", "url.dll,FileProtocolHandler", u)
		hide(c)
		_ = c.Start()
		return
	}
	openPath(u)
}

func showError(msg string) {
	if runtime.GOOS == "windows" {
		_, _ = runPS(`Add-Type -AssemblyName System.Windows.Forms; [void][System.Windows.Forms.MessageBox]::Show($env:CS_MSG,'`+appName+`')`, "CS_MSG="+msg)
		return
	}
	fmt.Fprintln(os.Stderr, msg)
}

// ---------------------------------------------------------------- control panel (127.0.0.1 only)

const panelSig = "codesolo-panel"

func pingPanel(port int) bool {
	cl := http.Client{Timeout: 700 * time.Millisecond}
	resp, err := cl.Get(fmt.Sprintf("http://127.0.0.1:%d/api/ping", port))
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 64))
	return strings.TrimSpace(string(b)) == panelSig
}

func (rx *Receiver) startPanel() (int, error) {
	ln, err := net.Listen("tcp", fmt.Sprintf("127.0.0.1:%d", rx.cfg.PanelPort))
	if err != nil {
		if ln, err = net.Listen("tcp", "127.0.0.1:0"); err != nil {
			return 0, err
		}
	}
	port := ln.Addr().(*net.TCPAddr).Port
	html, _ := assets.ReadFile("assets/panel.html")
	logo, _ := assets.ReadFile("assets/logo.png")
	fav, _ := assets.ReadFile("assets/favicon.png")
	page := strings.ReplaceAll(strings.ReplaceAll(string(html), "{{APP}}", appName), "{{AUTHOR}}", author)
	page = strings.ReplaceAll(page, "{{VERSION}}", version)
	hostWant := fmt.Sprintf("127.0.0.1:%d", port)

	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		securityHeaders(w)
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		_, _ = io.WriteString(w, page)
	})
	mux.HandleFunc("/api/ping", func(w http.ResponseWriter, r *http.Request) { _, _ = io.WriteString(w, panelSig) })
	mux.HandleFunc("/logo.png", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "image/png")
		_, _ = w.Write(logo)
	})
	mux.HandleFunc("/favicon.png", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "image/png")
		_, _ = w.Write(fav)
	})
	mux.HandleFunc("/api/qr.svg", func(w http.ResponseWriter, r *http.Request) {
		svg, err := qrSVG(rx.address())
		if err != nil {
			jsonErr(w, 500, err.Error())
			return
		}
		w.Header().Set("Content-Type", "image/svg+xml")
		w.Header().Set("Cache-Control", "no-store")
		_, _ = io.WriteString(w, svg)
	})
	mux.HandleFunc("/api/state", func(w http.ResponseWriter, r *http.Request) {
		rx.mu.Lock()
		code, active := rx.code, rx.active
		ts := make([]Transfer, len(rx.transfers))
		for i, t := range rx.transfers {
			ts[i] = *t
		}
		rx.mu.Unlock()
		rx.cfg.mu.Lock()
		dest, notify, theme := rx.cfg.Dest, !rx.cfg.NotifyOff, rx.cfg.Theme
		rx.cfg.mu.Unlock()
		ps := rx.phones()
		if ps == nil {
			ps = []phoneInfo{}
		}
		jsonOut(w, 200, map[string]any{
			"code": code, "address": rx.address(), "dest": dest, "phones": ps,
			"transfers": ts, "active": active, "startup": startupEnabled(), "outgoing": rx.outgoing(), "notify": notify, "theme": theme,
		})
	})
	post := func(path string, fn func(w http.ResponseWriter, r *http.Request)) {
		mux.HandleFunc(path, func(w http.ResponseWriter, r *http.Request) {
			if !postGuard(w, r) {
				return
			}
			fn(w, r)
		})
	}
	post("/api/pick-dest", func(w http.ResponseWriter, r *http.Request) {
		rx.cfg.mu.Lock()
		cur := rx.cfg.Dest
		rx.cfg.mu.Unlock()
		d, err := pickFolder(cur)
		if err != nil {
			jsonErr(w, 500, err.Error())
			return
		}
		if d == "" {
			jsonOut(w, 200, map[string]any{"changed": false})
			return
		}
		if err := os.MkdirAll(d, 0o755); err != nil {
			jsonErr(w, 400, "Could not use that folder.")
			return
		}
		rx.cfg.mu.Lock()
		rx.cfg.Dest = d
		rx.cfg.mu.Unlock()
		rx.cfg.save()
		jsonOut(w, 200, map[string]any{"changed": true})
	})
	post("/api/open-folder", func(w http.ResponseWriter, r *http.Request) {
		rx.cfg.mu.Lock()
		d := rx.cfg.Dest
		rx.cfg.mu.Unlock()
		_ = os.MkdirAll(d, 0o755)
		openPath(d)
		jsonOut(w, 200, map[string]any{"ok": true})
	})
	post("/api/offer", func(w http.ResponseWriter, r *http.Request) {
		var body struct{ Phone string }
		_ = json.NewDecoder(io.LimitReader(r.Body, 1024)).Decode(&body)
		key := rx.keyByID(body.Phone)
		if key == "" {
			jsonErr(w, 400, "Choose the phone shown on its sender page.")
			return
		}
		paths, err := pickFiles()
		if err != nil {
			jsonErr(w, 500, err.Error())
			return
		}
		jsonOut(w, 200, map[string]any{"count": rx.offer(key, paths)})
	})
	post("/api/stage", func(w http.ResponseWriter, r *http.Request) {
		size := r.ContentLength
		if size < 0 || size > maxFile {
			jsonErr(w, 411, "The file size is required.")
			return
		}
		keys := rx.keysFor(r.URL.Query().Get("phone"))
		if len(keys) == 0 {
			jsonErr(w, 400, "Choose the phone shown on its sender page.")
			return
		}
		raw := r.Header.Get("X-File-Name")
		if u, err := url.PathUnescape(raw); err == nil {
			raw = u
		}
		name := safeName(raw)
		if name == "" {
			jsonErr(w, 400, "Choose a file with a valid filename.")
			return
		}
		dir := filepath.Join(outgoingDir(), token(6))
		if err := os.MkdirAll(dir, 0o755); err != nil {
			jsonErr(w, 500, "Could not prepare the file.")
			return
		}
		if free, err := freeSpace(dir); err == nil && free < uint64(size)+64<<20 {
			_ = os.RemoveAll(dir)
			jsonErr(w, 507, "There is not enough free space on the PC.")
			return
		}
		path := filepath.Join(dir, name)
		f, err := os.Create(path)
		if err == nil {
			_, err = io.Copy(f, io.LimitReader(r.Body, size))
			if cerr := f.Close(); err == nil {
				err = cerr
			}
		}
		if st, serr := os.Stat(path); err != nil || serr != nil || st.Size() != size {
			_ = os.RemoveAll(dir)
			jsonErr(w, 400, "Preparing the file was interrupted. Try again.")
			return
		}
		n := 0
		for _, k := range keys {
			n += rx.offer(k, []string{path})
		}
		jsonOut(w, 200, map[string]any{"count": n})
	})
	post("/api/unoffer", func(w http.ResponseWriter, r *http.Request) {
		var body struct{ ID string }
		_ = json.NewDecoder(io.LimitReader(r.Body, 256)).Decode(&body)
		rx.unoffer(body.ID)
		jsonOut(w, 200, map[string]any{"ok": true})
	})
	post("/api/forget", func(w http.ResponseWriter, r *http.Request) {
		rx.forgetAll()
		jsonOut(w, 200, map[string]any{"ok": true})
	})
	post("/api/startup", func(w http.ResponseWriter, r *http.Request) {
		var body struct{ On bool }
		_ = json.NewDecoder(io.LimitReader(r.Body, 256)).Decode(&body)
		if err := setStartup(body.On); err != nil {
			jsonErr(w, 500, "Windows could not change the startup setting.")
			return
		}
		jsonOut(w, 200, map[string]any{"on": startupEnabled()})
	})
	post("/api/notify", func(w http.ResponseWriter, r *http.Request) {
		var body struct{ On bool }
		_ = json.NewDecoder(io.LimitReader(r.Body, 256)).Decode(&body)
		rx.cfg.mu.Lock()
		rx.cfg.NotifyOff = !body.On
		rx.cfg.mu.Unlock()
		rx.cfg.save()
		jsonOut(w, 200, map[string]any{"on": body.On})
	})
	post("/api/notify-test", func(w http.ResponseWriter, r *http.Request) {
		go toastNotify(appName, "Notifications are working. You will see this when a phone sends a file.")
		jsonOut(w, 200, map[string]any{"ok": true})
	})
	post("/api/theme", func(w http.ResponseWriter, r *http.Request) {
		var body struct{ Name string }
		_ = json.NewDecoder(io.LimitReader(r.Body, 256)).Decode(&body)
		if !validTheme[body.Name] {
			jsonErr(w, 400, "Unknown theme.")
			return
		}
		rx.cfg.mu.Lock()
		rx.cfg.Theme = body.Name
		rx.cfg.mu.Unlock()
		rx.cfg.save()
		jsonOut(w, 200, map[string]any{"ok": true})
	})
	post("/api/quit", func(w http.ResponseWriter, r *http.Request) {
		jsonOut(w, 200, map[string]any{"ok": true})
		go func() {
			_ = os.RemoveAll(outgoingDir())
			time.Sleep(200 * time.Millisecond)
			close(rx.quit)
		}()
	})

	h := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/ping" && r.Host != hostWant {
			http.Error(w, "forbidden", 403)
			return
		}
		mux.ServeHTTP(w, r)
	})
	go (&http.Server{Handler: h, ReadHeaderTimeout: 10 * time.Second}).Serve(ln)
	return port, nil
}

// ---------------------------------------------------------------- themes + Windows notifications

var validTheme = map[string]bool{"ocean": true, "violet": true, "emerald": true, "sunset": true, "rose": true, "graphite": true}

const (
	psAppID  = `{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe`
	appAUMID = "CodeSolo.App" // set on the installer's Start Menu shortcut
)

// toastAppID returns the branded id when the installer's Start Menu shortcut
// exists (so the toast says "CODE SOLO"), otherwise PowerShell's own id,
// which Windows always accepts.
func toastAppID() string {
	for _, base := range []string{os.Getenv("ProgramData"), os.Getenv("APPDATA")} {
		if base == "" {
			continue
		}
		lnk := filepath.Join(base, "Microsoft", "Windows", "Start Menu", "Programs", appName, appName+".lnk")
		if _, err := os.Stat(lnk); err == nil {
			return appAUMID
		}
	}
	return psAppID
}

func toastNotify(title, body string) {
	if runtime.GOOS != "windows" {
		return
	}
	const script = `[Windows.UI.Notifications.ToastNotificationManager,Windows.UI.Notifications,ContentType=WindowsRuntime]|Out-Null
[Windows.Data.Xml.Dom.XmlDocument,Windows.Data.Xml.Dom.XmlDocument,ContentType=WindowsRuntime]|Out-Null
$x=New-Object Windows.Data.Xml.Dom.XmlDocument
$x.LoadXml('<toast><visual><binding template="ToastGeneric"><text/><text/></binding></visual></toast>')
$n=$x.GetElementsByTagName('text')
$n.Item(0).AppendChild($x.CreateTextNode($env:CS_T))|Out-Null
$n.Item(1).AppendChild($x.CreateTextNode($env:CS_M))|Out-Null
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($env:CS_ID).Show([Windows.UI.Notifications.ToastNotification]::new($x))`
	_, _ = runPS(script, "CS_T="+title, "CS_M="+body, "CS_ID="+toastAppID())
}

// notifyReceived batches files that arrive close together into one toast.
func (rx *Receiver) notifyReceived(name string) {
	rx.cfg.mu.Lock()
	off := rx.cfg.NotifyOff
	rx.cfg.mu.Unlock()
	if off || runtime.GOOS != "windows" {
		return
	}
	rx.nmu.Lock()
	rx.nNames = append(rx.nNames, name)
	if rx.nTimer == nil {
		rx.nTimer = time.AfterFunc(1500*time.Millisecond, rx.flushNotify)
	}
	rx.nmu.Unlock()
}

func (rx *Receiver) flushNotify() {
	rx.nmu.Lock()
	names := rx.nNames
	rx.nNames = nil
	rx.nTimer = nil
	rx.nmu.Unlock()
	if len(names) == 0 {
		return
	}
	title, body := "File received", names[0]
	if len(names) > 1 {
		title = fmt.Sprintf("%d files received", len(names))
		body = fmt.Sprintf("%s and %d more", names[0], len(names)-1)
	}
	rx.cfg.mu.Lock()
	dest := rx.cfg.Dest
	rx.cfg.mu.Unlock()
	toastNotify(title, body+"\nSaved to "+dest)
}
