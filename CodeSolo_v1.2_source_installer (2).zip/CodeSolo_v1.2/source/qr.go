package main

import (
	"errors"
	"fmt"
	"strings"
)

// Minimal QR Code generator: byte mode, error correction level M, versions 1-10.

type eccInfo struct{ total, ec, g1n, g1d, g2n, g2d int }

var eccM = []eccInfo{
	{},
	{26, 10, 1, 16, 0, 0},
	{44, 16, 1, 28, 0, 0},
	{70, 26, 1, 44, 0, 0},
	{100, 18, 2, 32, 0, 0},
	{134, 24, 2, 43, 0, 0},
	{172, 16, 4, 27, 0, 0},
	{196, 18, 4, 31, 0, 0},
	{242, 22, 2, 38, 2, 39},
	{292, 22, 3, 36, 2, 37},
	{346, 26, 4, 43, 1, 44},
}

var alignPos = [][]int{nil, nil, {6, 18}, {6, 22}, {6, 26}, {6, 30}, {6, 34}, {6, 22, 38}, {6, 24, 42}, {6, 26, 46}, {6, 28, 50}}

func gfMul(x, y byte) byte {
	var z int
	for i := 7; i >= 0; i-- {
		z = (z << 1) ^ ((z >> 7) * 0x11D)
		z ^= int((y>>uint(i))&1) * int(x)
	}
	return byte(z)
}

func rsDivisor(degree int) []byte {
	result := make([]byte, degree)
	result[degree-1] = 1
	var root byte = 1
	for i := 0; i < degree; i++ {
		for j := 0; j < degree; j++ {
			result[j] = gfMul(result[j], root)
			if j+1 < degree {
				result[j] ^= result[j+1]
			}
		}
		root = gfMul(root, 2)
	}
	return result
}

func rsRemainder(data, div []byte) []byte {
	result := make([]byte, len(div))
	for _, b := range data {
		factor := b ^ result[0]
		copy(result, result[1:])
		result[len(result)-1] = 0
		for i := range result {
			result[i] ^= gfMul(div[i], factor)
		}
	}
	return result
}

type qrMatrix struct {
	size int
	mod  [][]bool
	fn   [][]bool
}

func (q *qrMatrix) setFn(x, y int, dark bool) {
	q.mod[y][x] = dark
	q.fn[y][x] = true
}

func bit(v int, i int) bool { return (v>>uint(i))&1 != 0 }

func (q *qrMatrix) drawFormat(mask int) {
	data := 0<<3 | mask // ECC level M = 0b00
	rem := data
	for i := 0; i < 10; i++ {
		rem = (rem << 1) ^ ((rem >> 9) * 0x537)
	}
	bits := (data<<10 | rem) ^ 0x5412
	for i := 0; i <= 5; i++ {
		q.setFn(8, i, bit(bits, i))
	}
	q.setFn(8, 7, bit(bits, 6))
	q.setFn(8, 8, bit(bits, 7))
	q.setFn(7, 8, bit(bits, 8))
	for i := 9; i < 15; i++ {
		q.setFn(14-i, 8, bit(bits, i))
	}
	for i := 0; i < 8; i++ {
		q.setFn(q.size-1-i, 8, bit(bits, i))
	}
	for i := 8; i < 15; i++ {
		q.setFn(8, q.size-15+i, bit(bits, i))
	}
	q.setFn(8, q.size-8, true)
}

func (q *qrMatrix) drawVersion(v int) {
	if v < 7 {
		return
	}
	rem := v
	for i := 0; i < 12; i++ {
		rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
	}
	bits := v<<12 | rem
	for i := 0; i < 18; i++ {
		b := bit(bits, i)
		a := q.size - 11 + i%3
		c := i / 3
		q.setFn(a, c, b)
		q.setFn(c, a, b)
	}
}

func abs(a int) int {
	if a < 0 {
		return -a
	}
	return a
}

func max2(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func (q *qrMatrix) drawFunctionPatterns(v int) {
	for i := 0; i < q.size; i++ {
		q.setFn(6, i, i%2 == 0)
		q.setFn(i, 6, i%2 == 0)
	}
	finder := func(cx, cy int) {
		for dy := -4; dy <= 4; dy++ {
			for dx := -4; dx <= 4; dx++ {
				d := max2(abs(dx), abs(dy))
				x, y := cx+dx, cy+dy
				if x >= 0 && x < q.size && y >= 0 && y < q.size {
					q.setFn(x, y, d != 2 && d != 4)
				}
			}
		}
	}
	finder(3, 3)
	finder(q.size-4, 3)
	finder(3, q.size-4)
	pos := alignPos[v]
	last := len(pos) - 1
	for i := range pos {
		for j := range pos {
			if (i == 0 && j == 0) || (i == 0 && j == last) || (i == last && j == 0) {
				continue
			}
			for dy := -2; dy <= 2; dy++ {
				for dx := -2; dx <= 2; dx++ {
					q.setFn(pos[i]+dx, pos[j]+dy, max2(abs(dx), abs(dy)) != 1)
				}
			}
		}
	}
	q.drawFormat(0)
	q.drawVersion(v)
}

func (q *qrMatrix) applyMask(m int) {
	for y := 0; y < q.size; y++ {
		for x := 0; x < q.size; x++ {
			var inv bool
			switch m {
			case 0:
				inv = (x+y)%2 == 0
			case 1:
				inv = y%2 == 0
			case 2:
				inv = x%3 == 0
			case 3:
				inv = (x+y)%3 == 0
			case 4:
				inv = (x/3+y/2)%2 == 0
			case 5:
				inv = x*y%2+x*y%3 == 0
			case 6:
				inv = (x*y%2+x*y%3)%2 == 0
			case 7:
				inv = ((x+y)%2+x*y%3)%2 == 0
			}
			if inv && !q.fn[y][x] {
				q.mod[y][x] = !q.mod[y][x]
			}
		}
	}
}

func (q *qrMatrix) penalty() int {
	n := q.size
	p := 0
	line := func(get func(i int) bool) {
		run := 1
		for i := 1; i < n; i++ {
			if get(i) == get(i-1) {
				run++
			} else {
				if run >= 5 {
					p += 3 + run - 5
				}
				run = 1
			}
		}
		if run >= 5 {
			p += 3 + run - 5
		}
		// finder-like patterns
		pat1 := []bool{true, false, true, true, true, false, true, false, false, false, false}
		pat2 := []bool{false, false, false, false, true, false, true, true, true, false, true}
		for s := 0; s+11 <= n; s++ {
			m1, m2 := true, true
			for k := 0; k < 11; k++ {
				v := get(s + k)
				if v != pat1[k] {
					m1 = false
				}
				if v != pat2[k] {
					m2 = false
				}
			}
			if m1 {
				p += 40
			}
			if m2 {
				p += 40
			}
		}
	}
	for y := 0; y < n; y++ {
		yy := y
		line(func(i int) bool { return q.mod[yy][i] })
	}
	for x := 0; x < n; x++ {
		xx := x
		line(func(i int) bool { return q.mod[i][xx] })
	}
	dark := 0
	for y := 0; y < n; y++ {
		for x := 0; x < n; x++ {
			if q.mod[y][x] {
				dark++
			}
			if x+1 < n && y+1 < n {
				c := q.mod[y][x]
				if c == q.mod[y][x+1] && c == q.mod[y+1][x] && c == q.mod[y+1][x+1] {
					p += 3
				}
			}
		}
	}
	total := n * n
	k := (abs(dark*20-total*10)+total-1)/total - 1
	if k > 0 {
		p += k * 10
	}
	return p
}

func makeQR(text string) ([][]bool, error) {
	data := []byte(text)
	v := 0
	for ver := 1; ver <= 10; ver++ {
		e := eccM[ver]
		capBytes := e.g1n*e.g1d + e.g2n*e.g2d
		countBits := 8
		if ver >= 10 {
			countBits = 16
		}
		if 4+countBits+8*len(data) <= 8*capBytes {
			v = ver
			break
		}
	}
	if v == 0 {
		return nil, errors.New("The local address is too long for this QR code.")
	}
	e := eccM[v]
	capBytes := e.g1n*e.g1d + e.g2n*e.g2d
	countBits := 8
	if v >= 10 {
		countBits = 16
	}
	var bits []bool
	push := func(val, n int) {
		for i := n - 1; i >= 0; i-- {
			bits = append(bits, bit(val, i))
		}
	}
	push(4, 4)
	push(len(data), countBits)
	for _, b := range data {
		push(int(b), 8)
	}
	for i := 0; i < 4 && len(bits) < 8*capBytes; i++ {
		bits = append(bits, false)
	}
	for len(bits)%8 != 0 {
		bits = append(bits, false)
	}
	cw := make([]byte, 0, capBytes)
	for i := 0; i < len(bits); i += 8 {
		var b byte
		for j := 0; j < 8; j++ {
			b <<= 1
			if bits[i+j] {
				b |= 1
			}
		}
		cw = append(cw, b)
	}
	for pad := byte(0xEC); len(cw) < capBytes; pad ^= 0xEC ^ 0x11 {
		cw = append(cw, pad)
	}
	// split into blocks
	var blocks, ecs [][]byte
	div := rsDivisor(e.ec)
	pos := 0
	add := func(n, d int) {
		for i := 0; i < n; i++ {
			blk := cw[pos : pos+d]
			pos += d
			blocks = append(blocks, blk)
			ecs = append(ecs, rsRemainder(blk, div))
		}
	}
	add(e.g1n, e.g1d)
	add(e.g2n, e.g2d)
	var all []byte
	maxd := e.g1d
	if e.g2n > 0 {
		maxd = e.g2d
	}
	for i := 0; i < maxd; i++ {
		for _, b := range blocks {
			if i < len(b) {
				all = append(all, b[i])
			}
		}
	}
	for i := 0; i < e.ec; i++ {
		for _, b := range ecs {
			all = append(all, b[i])
		}
	}
	if len(all) != e.total {
		return nil, fmt.Errorf("qr: internal size mismatch %d != %d", len(all), e.total)
	}
	size := 17 + 4*v
	q := &qrMatrix{size: size}
	q.mod = make([][]bool, size)
	q.fn = make([][]bool, size)
	for i := range q.mod {
		q.mod[i] = make([]bool, size)
		q.fn[i] = make([]bool, size)
	}
	q.drawFunctionPatterns(v)
	// place data
	i := 0
	total := len(all) * 8
	for right := size - 1; right >= 1; right -= 2 {
		if right == 6 {
			right = 5
		}
		for vert := 0; vert < size; vert++ {
			for j := 0; j < 2; j++ {
				x := right - j
				upward := ((right + 1) & 2) == 0
				y := vert
				if upward {
					y = size - 1 - vert
				}
				if !q.fn[y][x] && i < total {
					q.mod[y][x] = bit(int(all[i>>3]), 7-(i&7))
					i++
				}
			}
		}
	}
	best, bestP := 0, 1<<30
	for m := 0; m < 8; m++ {
		q.applyMask(m)
		q.drawFormat(m)
		if p := q.penalty(); p < bestP {
			best, bestP = m, p
		}
		q.applyMask(m)
	}
	q.applyMask(best)
	q.drawFormat(best)
	return q.mod, nil
}

func qrSVG(text string) (string, error) {
	m, err := makeQR(text)
	if err != nil {
		return "", err
	}
	n := len(m)
	const quiet = 2
	var sb strings.Builder
	fmt.Fprintf(&sb, `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" shape-rendering="crispEdges"><rect width="100%%" height="100%%" fill="#fff"/><path fill="#111" d="`, n+2*quiet, n+2*quiet)
	for y := 0; y < n; y++ {
		for x := 0; x < n; x++ {
			if m[y][x] {
				fmt.Fprintf(&sb, "M%d %dh1v1h-1z", x+quiet, y+quiet)
			}
		}
	}
	sb.WriteString(`"/></svg>`)
	return sb.String(), nil
}
