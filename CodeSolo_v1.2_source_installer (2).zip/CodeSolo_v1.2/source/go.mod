module codesolo

go 1.21
