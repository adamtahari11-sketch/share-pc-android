package main

import (
	"fmt"
	"os"
)

const (
	appName = "CODE SOLO"
	author  = "by: Code Solo"
	version = "1.2.0"
)

func has(flag string) bool {
	for _, a := range os.Args[1:] {
		if a == flag {
			return true
		}
	}
	return false
}

func main() {
	background := has("--background")
	noOpen := has("--no-open")
	cfg := loadConfig()

	// Already running? Just bring up its window.
	if cfg.PanelPort != 0 && pingPanel(cfg.PanelPort) {
		if !background && !noOpen {
			openPanel(cfg.PanelPort)
		}
		return
	}

	_ = os.RemoveAll(outgoingDir())
	rx := newReceiver(cfg)
	if err := rx.start(); err != nil {
		showError(err.Error())
		return
	}
	pp, err := rx.startPanel()
	if err != nil {
		showError("Code Solo could not start: " + err.Error())
		return
	}
	cfg.PanelPort = pp
	cfg.save()
	if has("--print") {
		fmt.Printf("panel=%d phone=%s code=%s dest=%s\n", pp, rx.address(), rx.code, cfg.Dest)
	}
	if !background && !noOpen {
		openPanel(pp)
	}
	<-rx.quit
}
