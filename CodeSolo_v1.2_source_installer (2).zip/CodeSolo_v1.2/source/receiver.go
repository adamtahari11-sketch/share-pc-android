package main

import (
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"embed"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/big"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
	"time"
)

const (
	maxPhones = 64
	maxFile   = int64(64) << 30
	chunk     = 1 << 20
)

//go:embed assets/*
var assets embed.FS

// ---------------------------------------------------------------- config

type Phone struct {
	Name  string `json:"name"`
	Added int64  `json:"added"`
}

type Config struct {
	mu        sync.Mutex
	path      string
	Dest      string           `json:"dest"`
	Port      int              `json:"port"`
	PanelPort int              `json:"panelPort"`
	Phones    map[string]Phone `json:"phones"`
	Theme     string           `json:"theme"`
	NotifyOff bool             `json:"notifyOff"`
}

func configDir() string {
	base := os.Getenv("APPDATA")
	if base == "" {
		h, _ := os.UserHomeDir()
		base = filepath.Join(h, ".config")
	}
	d := filepath.Join(base, "CodeSolo")
	_ = os.MkdirAll(d, 0o755)
	return d
}

func loadConfig() *Config {
	home, _ := os.UserHomeDir()
	c := &Config{
		path:   filepath.Join(configDir(), "settings.json"),
		Dest:   filepath.Join(home, "Downloads", "Code Solo Received"),
		Port:   8080,
		Phones: map[string]Phone{},
	}
	if b, err := os.ReadFile(c.path); err == nil {
		_ = json.Unmarshal(b, c)
	}
	if c.Phones == nil {
		c.Phones = map[string]Phone{}
	}
	return c
}

func (c *Config) save() {
	c.mu.Lock()
	defer c.mu.Unlock()
	b, _ := json.MarshalIndent(c, "", "  ")
	tmp := c.path + ".tmp"
	if os.WriteFile(tmp, b, 0o600) == nil {
		_ = os.Rename(tmp, c.path)
	}
}

// ---------------------------------------------------------------- state

type Offer struct {
	Key   string
	Path  string
	Name  string
	Size  int64
	MTime time.Time
}

type Transfer struct {
	ID    int    `json:"id"`
	Name  string `json:"name"`
	Size  int64  `json:"size"`
	Done  int64  `json:"done"`
	Dir   string `json:"dir"` // in | out
	State string `json:"state"`
	Time  int64  `json:"time"`
}

type Receiver struct {
	cfg       *Config
	mu        sync.Mutex
	code      string
	offers    map[string]*Offer
	attempts  map[string][]time.Time
	transfers []*Transfer
	nextID    int
	active    int
	port      int
	quit      chan struct{}
	srv       *http.Server
	nmu       sync.Mutex
	nNames    []string
	nTimer    *time.Timer
}

func newReceiver(cfg *Config) *Receiver {
	r := &Receiver{cfg: cfg, offers: map[string]*Offer{}, attempts: map[string][]time.Time{}, quit: make(chan struct{})}
	r.code = newCode()
	return r
}

func newCode() string {
	n, _ := rand.Int(rand.Reader, big.NewInt(1000000))
	return fmt.Sprintf("%06d", n.Int64())
}

func token(n int) string {
	b := make([]byte, n)
	_, _ = rand.Read(b)
	return base64.RawURLEncoding.EncodeToString(b)
}

func phoneID(key string) string {
	h := sha256.Sum256([]byte(key))
	return hex.EncodeToString(h[:4])
}

func (r *Receiver) newTransfer(name string, size int64, dir string) *Transfer {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.nextID++
	t := &Transfer{ID: r.nextID, Name: name, Size: size, Dir: dir, State: "active", Time: time.Now().Unix()}
	r.transfers = append([]*Transfer{t}, r.transfers...)
	if len(r.transfers) > 40 {
		r.transfers = r.transfers[:40]
	}
	if dir == "in" || dir == "out" {
		r.active++
	}
	return t
}

func (r *Receiver) finish(t *Transfer, state string) {
	r.mu.Lock()
	t.State = state
	r.active--
	r.mu.Unlock()
}

func (r *Receiver) progress(t *Transfer, done int64) {
	r.mu.Lock()
	t.Done = done
	r.mu.Unlock()
}

// ---------------------------------------------------------------- helpers

var badChars = regexp.MustCompile(`[<>:"/\\|?*\x00-\x1f]`)
var reserved = map[string]bool{"CON": true, "PRN": true, "AUX": true, "NUL": true}

func init() {
	for i := 1; i <= 9; i++ {
		reserved[fmt.Sprintf("COM%d", i)] = true
		reserved[fmt.Sprintf("LPT%d", i)] = true
	}
}

func safeName(raw string) string {
	raw = strings.ReplaceAll(raw, "\\", "/")
	name := strings.TrimSpace(raw[strings.LastIndex(raw, "/")+1:])
	name = badChars.ReplaceAllString(name, "_")
	name = strings.TrimRight(name, ". ")
	name = strings.TrimLeft(name, ".")
	if name == "" {
		return ""
	}
	ext := filepath.Ext(name)
	stem := strings.TrimSuffix(name, ext)
	if reserved[strings.ToUpper(stem)] {
		stem = "_" + stem
	}
	if len(stem)+len(ext) > 200 {
		stem = stem[:200-len(ext)]
	}
	return stem + ext
}

func humanSize(n int64) string {
	f := float64(n)
	for _, u := range []string{"B", "KB", "MB", "GB"} {
		if f < 1024 {
			if u == "B" {
				return fmt.Sprintf("%.0f B", f)
			}
			return fmt.Sprintf("%.1f %s", f, u)
		}
		f /= 1024
	}
	return fmt.Sprintf("%.1f TB", f)
}

func localIP() string {
	if c, err := net.Dial("udp4", "10.255.255.255:1"); err == nil { // no packet is sent
		defer c.Close()
		if a, ok := c.LocalAddr().(*net.UDPAddr); ok && !a.IP.IsLoopback() {
			return a.IP.String()
		}
	}
	addrs, _ := net.InterfaceAddrs()
	for _, a := range addrs {
		if ip, ok := a.(*net.IPNet); ok && ip.IP.To4() != nil && !ip.IP.IsLoopback() {
			return ip.IP.String()
		}
	}
	return "127.0.0.1"
}

func (r *Receiver) address() string { return fmt.Sprintf("http://%s:%d", localIP(), r.port) }

func deviceLabel(ua, ip string) string {
	k := "Browser"
	switch {
	case strings.Contains(ua, "iPhone"):
		k = "iPhone"
	case strings.Contains(ua, "iPad"):
		k = "iPad"
	case strings.Contains(ua, "Android"):
		k = "Android"
	}
	return fmt.Sprintf("%s (%s)", k, ip)
}

// ---------------------------------------------------------------- pairing

func (r *Receiver) tryPair(ip, ua, code string) (string, int, string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	now := time.Now()
	var hist []time.Time
	for _, t := range r.attempts[ip] {
		if now.Sub(t) < time.Minute {
			hist = append(hist, t)
		}
	}
	if len(hist) >= 5 {
		return "", 429, "Too many attempts. Wait one minute, then use the code currently on the PC."
	}
	r.attempts[ip] = append(hist, now)
	if subtle.ConstantTimeCompare([]byte(code), []byte(r.code)) != 1 {
		return "", 403, "Wrong code. Check the six-digit code on the PC."
	}
	r.cfg.mu.Lock()
	if len(r.cfg.Phones) >= maxPhones {
		r.cfg.mu.Unlock()
		return "", 409, "The receiver has 64 paired phones. Use Forget phones on the PC."
	}
	key := token(24)
	r.cfg.Phones[key] = Phone{Name: deviceLabel(ua, ip), Added: now.Unix()}
	r.cfg.mu.Unlock()
	r.code = newCode()
	delete(r.attempts, ip)
	go r.cfg.save()
	return key, 200, ""
}

func (r *Receiver) forgetAll() {
	r.mu.Lock()
	r.cfg.mu.Lock()
	r.cfg.Phones = map[string]Phone{}
	r.cfg.mu.Unlock()
	r.offers = map[string]*Offer{}
	r.code = newCode()
	r.mu.Unlock()
	r.cfg.save()
}

func (r *Receiver) hasKey(k string) bool {
	if k == "" {
		return false
	}
	r.cfg.mu.Lock()
	defer r.cfg.mu.Unlock()
	_, ok := r.cfg.Phones[k]
	return ok
}

type phoneInfo struct {
	ID   string `json:"id"`
	Name string `json:"name"`
	Kind string `json:"kind"`
}

func kindOf(name string) string {
	switch {
	case strings.HasPrefix(name, "iPhone"), strings.HasPrefix(name, "iPad"):
		return "ios"
	case strings.HasPrefix(name, "Android"):
		return "android"
	}
	return "other"
}

func (r *Receiver) phones() []phoneInfo {
	r.cfg.mu.Lock()
	defer r.cfg.mu.Unlock()
	var out []phoneInfo
	for k, p := range r.cfg.Phones {
		out = append(out, phoneInfo{phoneID(k), p.Name, kindOf(p.Name)})
	}
	return out
}

func (r *Receiver) keyByID(id string) string {
	r.cfg.mu.Lock()
	defer r.cfg.mu.Unlock()
	for k := range r.cfg.Phones {
		if phoneID(k) == id {
			return k
		}
	}
	return ""
}

func (r *Receiver) keysFor(id string) []string {
	r.cfg.mu.Lock()
	defer r.cfg.mu.Unlock()
	var out []string
	for k := range r.cfg.Phones {
		if id == "all" || phoneID(k) == id {
			out = append(out, k)
		}
	}
	return out
}

type outItem struct {
	ID    string `json:"id"`
	Name  string `json:"name"`
	Size  string `json:"size"`
	Phone string `json:"phone"`
}

func (r *Receiver) outgoing() []outItem {
	out := []outItem{}
	r.mu.Lock()
	defer r.mu.Unlock()
	r.cfg.mu.Lock()
	defer r.cfg.mu.Unlock()
	for id, o := range r.offers {
		out = append(out, outItem{id, o.Name, humanSize(o.Size), r.cfg.Phones[o.Key].Name})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func (r *Receiver) unoffer(id string) {
	r.mu.Lock()
	o := r.offers[id]
	delete(r.offers, id)
	shared := false
	if o != nil {
		for _, x := range r.offers {
			if x.Path == o.Path {
				shared = true
			}
		}
	}
	r.mu.Unlock()
	if o != nil && !shared && strings.HasPrefix(o.Path, outgoingDir()) {
		_ = os.RemoveAll(filepath.Dir(o.Path))
	}
}

func outgoingDir() string { return filepath.Join(configDir(), "outgoing") + string(filepath.Separator) }

func (r *Receiver) offer(key string, paths []string) int {
	n := 0
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, p := range paths {
		st, err := os.Stat(p)
		if err != nil || st.IsDir() {
			continue
		}
		r.offers[token(9)] = &Offer{Key: key, Path: p, Name: filepath.Base(p), Size: st.Size(), MTime: st.ModTime()}
		n++
	}
	return n
}

// ---------------------------------------------------------------- phone server

func jsonOut(w http.ResponseWriter, code int, v any) {
	b, _ := json.Marshal(v)
	h := w.Header()
	h.Set("Content-Type", "application/json; charset=utf-8")
	h.Set("Cache-Control", "no-store")
	h.Set("X-Content-Type-Options", "nosniff")
	h.Set("Connection", "close")
	w.WriteHeader(code)
	_, _ = w.Write(b)
}

func jsonErr(w http.ResponseWriter, code int, msg string) {
	jsonOut(w, code, map[string]string{"error": msg})
}

func securityHeaders(w http.ResponseWriter) {
	h := w.Header()
	h.Set("X-Content-Type-Options", "nosniff")
	h.Set("X-Frame-Options", "DENY")
	h.Set("Referrer-Policy", "no-referrer")
	h.Set("Cache-Control", "no-store")
	h.Set("Content-Security-Policy", "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; form-action 'none'; frame-ancestors 'none'")
}

func lanOnly(r *http.Request) bool {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return false
	}
	ip := net.ParseIP(strings.Split(host, "%")[0])
	return ip != nil && (ip.IsPrivate() || ip.IsLoopback() || ip.IsLinkLocalUnicast())
}

func hostOK(r *http.Request) bool {
	h, _, err := net.SplitHostPort(r.Host)
	if err != nil {
		h = r.Host
	}
	h = strings.Trim(h, "[]")
	return net.ParseIP(h) != nil || strings.EqualFold(h, "localhost") || strings.HasSuffix(strings.ToLower(h), ".local")
}

func (rx *Receiver) keyFrom(r *http.Request, headerOnly bool) string {
	k := r.Header.Get("X-Receiver-Key")
	if k == "" && !headerOnly {
		if c, err := r.Cookie("key"); err == nil {
			k = c.Value
		}
	}
	if rx.hasKey(k) {
		return k
	}
	return ""
}

func (rx *Receiver) phoneHandler() http.Handler {
	mux := http.NewServeMux()
	page, _ := assets.ReadFile("assets/sender.html")
	logo, _ := assets.ReadFile("assets/logo.png")
	fav, _ := assets.ReadFile("assets/favicon.png")
	html := strings.ReplaceAll(string(page), "{{APP}}", appName)

	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			jsonErr(w, 404, "Page not found.")
			return
		}
		securityHeaders(w)
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		_, _ = io.WriteString(w, html)
	})
	png := func(b []byte) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "image/png")
			w.Header().Set("Cache-Control", "max-age=3600")
			_, _ = w.Write(b)
		}
	}
	mux.HandleFunc("/logo.png", png(logo))
	mux.HandleFunc("/favicon.png", png(fav))
	mux.HandleFunc("/api/inbox", func(w http.ResponseWriter, r *http.Request) {
		key := rx.keyFrom(r, false)
		if key == "" {
			jsonErr(w, 401, "Pair this phone again.")
			return
		}
		type f struct {
			ID   string `json:"id"`
			Name string `json:"name"`
			Size string `json:"size"`
		}
		files := []f{}
		rx.mu.Lock()
		for id, o := range rx.offers {
			if o.Key == key {
				files = append(files, f{id, o.Name, humanSize(o.Size)})
			}
		}
		rx.mu.Unlock()
		jsonOut(w, 200, map[string]any{"files": files})
	})
	mux.HandleFunc("/download/", rx.handleDownload)
	mux.HandleFunc("/api/pair", func(w http.ResponseWriter, r *http.Request) {
		if !postGuard(w, r) {
			return
		}
		var body struct{ Code string }
		if r.ContentLength <= 0 || r.ContentLength > 1024 || json.NewDecoder(io.LimitReader(r.Body, 1024)).Decode(&body) != nil {
			jsonErr(w, 400, "Bad request.")
			return
		}
		ip, _, _ := net.SplitHostPort(r.RemoteAddr)
		key, status, msg := rx.tryPair(ip, r.UserAgent(), body.Code)
		if key == "" {
			jsonErr(w, status, msg)
			return
		}
		jsonOut(w, 200, map[string]string{"key": key})
	})
	mux.HandleFunc("/api/send", rx.handleSend)

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !lanOnly(r) {
			jsonErr(w, 403, "Local network only.")
			return
		}
		if !hostOK(r) {
			jsonErr(w, 403, "Use the local address shown on the PC.")
			return
		}
		mux.ServeHTTP(w, r)
	})
}

func postGuard(w http.ResponseWriter, r *http.Request) bool {
	if r.Method != http.MethodPost {
		jsonErr(w, 405, "This request method is unavailable.")
		return false
	}
	if r.Header.Get("X-Requested-With") != "fetch" {
		jsonErr(w, 403, "Open the sender page directly from the PC address.")
		return false
	}
	if o := r.Header.Get("Origin"); o != "" {
		if u, err := url.Parse(o); err != nil || u.Host != r.Host {
			jsonErr(w, 403, "Open the sender page directly from the PC address.")
			return false
		}
	}
	return true
}

func (rx *Receiver) handleDownload(w http.ResponseWriter, r *http.Request) {
	id := strings.TrimPrefix(r.URL.Path, "/download/")
	key := rx.keyFrom(r, false)
	rx.mu.Lock()
	o := rx.offers[id]
	rx.mu.Unlock()
	if key == "" || o == nil || o.Key != key {
		jsonErr(w, 404, "This file offer has expired or belongs to another phone.")
		return
	}
	f, err := os.Open(o.Path)
	if err != nil {
		jsonErr(w, 404, "The file is no longer available on the PC.")
		return
	}
	defer f.Close()
	st, err := f.Stat()
	if err != nil || st.Size() != o.Size || !st.ModTime().Equal(o.MTime) {
		jsonErr(w, 409, "The file changed. Select it again on the PC.")
		return
	}
	t := rx.newTransfer(o.Name, o.Size, "out")
	h := w.Header()
	h.Set("Content-Type", "application/octet-stream")
	h.Set("Content-Length", fmt.Sprint(o.Size))
	h.Set("Content-Disposition", "attachment; filename*=UTF-8''"+strings.ReplaceAll(url.QueryEscape(o.Name), "+", "%20"))
	h.Set("X-Content-Type-Options", "nosniff")
	h.Set("Cache-Control", "no-store")
	buf := make([]byte, chunk)
	var done int64
	rc := http.NewResponseController(w)
	for {
		n, rerr := f.Read(buf)
		if n > 0 {
			_ = rc.SetWriteDeadline(time.Now().Add(60 * time.Second))
			if _, werr := w.Write(buf[:n]); werr != nil {
				rx.finish(t, "failed")
				return
			}
			done += int64(n)
			rx.progress(t, done)
		}
		if rerr != nil {
			if rerr == io.EOF {
				rx.finish(t, "done")
			} else {
				rx.finish(t, "failed")
			}
			return
		}
	}
}

func (rx *Receiver) handleSend(w http.ResponseWriter, r *http.Request) {
	if !postGuard(w, r) {
		return
	}
	if rx.keyFrom(r, true) == "" {
		jsonErr(w, 401, "Pair this phone again.")
		return
	}
	size := r.ContentLength
	if size < 0 {
		jsonErr(w, 411, "The file size is required.")
		return
	}
	if size > maxFile {
		jsonErr(w, 413, "The file exceeds 64 GB.")
		return
	}
	raw := r.Header.Get("X-File-Name")
	if u, err := url.PathUnescape(raw); err == nil {
		raw = u
	}
	name := safeName(raw)
	if name == "" {
		jsonErr(w, 400, "Choose a file with a valid filename.")
		return
	}
	rx.cfg.mu.Lock()
	dest := rx.cfg.Dest
	rx.cfg.mu.Unlock()
	if err := os.MkdirAll(dest, 0o755); err != nil {
		jsonErr(w, 500, "Check that the destination folder on the PC is connected and writable.")
		return
	}
	if free, err := freeSpace(dest); err == nil && free < uint64(size)+64<<20 {
		jsonErr(w, 507, "There is not enough free space in the PC destination.")
		return
	}
	tmp := filepath.Join(dest, ".incoming-"+token(6)+".part")
	out, err := os.OpenFile(tmp, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0o644)
	if err != nil {
		jsonErr(w, 500, "Check that the destination folder on the PC is connected and writable.")
		return
	}
	t := rx.newTransfer(name, size, "in")
	rc := http.NewResponseController(w)
	buf := make([]byte, chunk)
	var got int64
	var rerr error
	for got < size {
		_ = rc.SetReadDeadline(time.Now().Add(60 * time.Second))
		want := int64(len(buf))
		if size-got < want {
			want = size - got
		}
		n, err := r.Body.Read(buf[:want])
		if n > 0 {
			if _, werr := out.Write(buf[:n]); werr != nil {
				rerr = werr
				break
			}
			got += int64(n)
			rx.progress(t, got)
		}
		if err != nil {
			if err != io.EOF {
				rerr = err
			}
			break
		}
	}
	out.Close()
	if rerr != nil || got != size {
		_ = os.Remove(tmp)
		rx.finish(t, "failed")
		jsonErr(w, 400, "Transfer interrupted. Send this file again.")
		return
	}
	rx.mu.Lock()
	ext := filepath.Ext(name)
	stem := strings.TrimSuffix(name, ext)
	final := filepath.Join(dest, name)
	for i := 1; ; i++ {
		if _, err := os.Stat(final); errors.Is(err, os.ErrNotExist) {
			break
		}
		if i > 999 {
			rx.mu.Unlock()
			_ = os.Remove(tmp)
			rx.finish(t, "failed")
			jsonErr(w, 409, "Too many files have this name. Choose another destination folder.")
			return
		}
		final = filepath.Join(dest, fmt.Sprintf("%s (%d)%s", stem, i, ext))
	}
	err = os.Rename(tmp, final)
	if err == nil {
		t.Name = filepath.Base(final)
	}
	rx.mu.Unlock()
	if err != nil {
		_ = os.Remove(tmp)
		rx.finish(t, "failed")
		jsonErr(w, 500, "The receiver could not complete this request.")
		return
	}
	rx.finish(t, "done")
	rx.notifyReceived(t.Name)
	jsonOut(w, 200, map[string]any{"ok": true, "name": t.Name})
}

func (rx *Receiver) start() error {
	ports := []int{rx.cfg.Port}
	for p := 8080; p <= 8100; p++ {
		if p != rx.cfg.Port {
			ports = append(ports, p)
		}
	}
	var last error
	for _, p := range ports {
		ln, err := net.Listen("tcp", fmt.Sprintf("0.0.0.0:%d", p))
		if err != nil {
			last = err
			continue
		}
		rx.port = p
		rx.cfg.Port = p
		rx.srv = &http.Server{Handler: rx.phoneHandler(), ReadHeaderTimeout: 15 * time.Second, IdleTimeout: 30 * time.Second}
		go rx.srv.Serve(ln)
		go rx.cfg.save()
		return nil
	}
	return fmt.Errorf("Ports 8080 through 8100 are unavailable. Close the app using a port and reopen Code Solo. (%v)", last)
}
