@echo off
setlocal
cd /d "%~dp0"

echo [1/2] Building CodeSolo.exe with Go...
where go >nul 2>nul || (echo Go is not installed. Get it from https://go.dev/dl/ & exit /b 1)
pushd source
set GOOS=windows
set GOARCH=amd64
set CGO_ENABLED=0
go build -ldflags "-H=windowsgui -s -w" -o "..\installer\CodeSolo.exe" .
if errorlevel 1 (popd & echo Go build failed. & exit /b 1)
popd

echo [2/2] Building the installer with Inno Setup...
set ISCC=
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%LocalAppData%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LocalAppData%\Programs\Inno Setup 6\ISCC.exe"
if "%ISCC%"=="" (echo Inno Setup 6 not found. Get it from https://jrsoftware.org/isdl.php & exit /b 1)
"%ISCC%" "installer\CodeSolo.iss"
if errorlevel 1 (echo Installer build failed. & exit /b 1)

echo.
echo Done: installer\output\CodeSolo_Setup_1.2.0.exe
