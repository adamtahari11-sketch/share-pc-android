CODE SOLO v1.2 - Phone <-> Windows file transfer

NEW IN 1.2
- Real installer (wizard, Start Menu, Desktop shortcut, entry in Settings > Apps for uninstall)
- Color themes (Settings > Color theme)
- Particle animation while a transfer is running, confetti when it finishes (Settings > Effects)
- Windows notification when a phone sends you a file (Settings > Windows notification)

BUILD THE INSTALLER (on Windows)
1. Install Go            https://go.dev/dl/
2. Install Inno Setup 6  https://jrsoftware.org/isdl.php  (version 6.3 or newer)
3. Double-click build.bat
   Result: installer\output\CodeSolo_Setup_1.2.0.exe

Notes
- Unsigned installers trigger SmartScreen ("More info" > "Run anyway"). A code-signing certificate removes it.
- To release a new version, bump the version in installer\CodeSolo.iss and source\main.go. Keep the AppId GUID unchanged.
- Settings and paired phones live in %APPDATA%\CodeSolo (the uninstaller asks whether to delete them).
